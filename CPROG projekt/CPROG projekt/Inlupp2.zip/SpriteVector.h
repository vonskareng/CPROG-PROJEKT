#ifndef SPRITEVECTOR_H
#define SPRITEVECTOR_H

namespace cgame {
	
	struct SpriteVector {
		int x;
		int y;
	};
}


#endif