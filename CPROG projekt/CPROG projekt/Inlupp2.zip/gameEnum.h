#ifndef GAMEENUM_H
#define GAMEENUM_H 

namespace cgame {
	enum mouseMovement { enableMouseX, enableMouseY, enableMouseXandY };
}
#endif
