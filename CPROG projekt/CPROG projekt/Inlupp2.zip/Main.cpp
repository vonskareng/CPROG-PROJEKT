#include "Game.h"



int main(int argc, char** argv) {
	Game g;
	g.initialize();
	g.run();
	
	return 0;
}

