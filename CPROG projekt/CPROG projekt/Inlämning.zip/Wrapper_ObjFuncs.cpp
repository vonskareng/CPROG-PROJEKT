#include "Wrapper_ObjFuncs.h"

namespace cgame {
	Wrapper_ObjFuncs::~Wrapper_ObjFuncs() {

	}
}