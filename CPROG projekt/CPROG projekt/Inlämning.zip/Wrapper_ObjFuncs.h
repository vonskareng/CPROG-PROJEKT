#ifndef WRAPPER_OBJFUNCS_H
#define WRAPPER_OBJFUNCS_H
namespace cgame {
	class Wrapper_ObjFuncs
	{
	public:
		virtual void doFunc() {}
		virtual ~Wrapper_ObjFuncs();
	};
}
#endif